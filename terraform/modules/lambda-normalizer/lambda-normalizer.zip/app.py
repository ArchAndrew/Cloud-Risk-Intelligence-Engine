import json
import os
import boto3
from datetime import datetime, timezone

lambda_client = boto3.client("lambda")

RISK_ENGINE_FUNCTION_NAME = os.environ.get(
    "RISK_ENGINE_FUNCTION_NAME",
    "machine-lite-dev-risk-engine"
)

def lambda_handler(event, context):
    print("Received raw event:", json.dumps(event))

    normalized_event = {
        "event_id": event.get("id", "unknown"),
        "source": event.get("source", "unknown"),
        "detail_type": event.get("detail-type", "unknown"),
        "account": event.get("account", "unknown"),
        "region": event.get("region", "unknown"),
        "time": event.get("time", datetime.now(timezone.utc).isoformat()),
        "detail": event.get("detail", {}),
        "normalized_at": datetime.now(timezone.utc).isoformat(),
        "pipeline_stage": "normalized"
    }

    print("Normalized event:", json.dumps(normalized_event))

    response = lambda_client.invoke(
        FunctionName=RISK_ENGINE_FUNCTION_NAME,
        InvocationType="Event",
        Payload=json.dumps(normalized_event).encode("utf-8")
    )

    print("Risk engine invocation response:", response)

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": "Event normalized and sent to risk engine",
            "risk_engine_status_code": response.get("StatusCode"),
            "normalized_event": normalized_event
        })
    }